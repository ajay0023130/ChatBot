from django.db import models
from django.contrib.auth.models import User
import datetime



class Bot(models.Model):
    question = models.CharField(max_length=333,help_text='The max length of the question is 4000.')
    answers = models.CharField(max_length=333)
    time = models.DateTimeField(auto_now="True")
    user = models.ForeignKey(User, related_name='user', on_delete=models.CASCADE,null=True)
    # null = True means - if user can't fill this field when programe is run with out error
    def __str__(self):
        return self.question



    

       
      
        
    


    
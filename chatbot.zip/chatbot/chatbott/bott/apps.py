from django.apps import AppConfig


class BottConfig(AppConfig):
    name = 'bott'
